# Restaurant Apps A.K.A Resto Finder
## Find the best Restaurant in your area
This repository containing my Project (Submission) on [Menjadi Front-End Web Developer Expert (Dicoding Class)](https://www.dicoding.com/academies/219/).  
![Resto Finder Color Palette](https://github.com/virgiawankusuma/restaurant-apps/blob/master/src/public/images/Color%20Hunt%20Palette%20c36a2de2c275eadca6fbfbfb.png "Resto Finder Color Palette")
